
  # Create Accounting App Pages

  This is a code bundle for Create Accounting App Pages. The original project is available at https://www.figma.com/design/iaT1T4wujqx9TXxGnqLgvF/Create-Accounting-App-Pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  