import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { 
  Home, 
  CreditCard, 
  BarChart3, 
  UserCheck,
  Sparkles
} from "lucide-react";

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function Navigation({ currentPage, onPageChange }: NavigationProps) {
  const mainNavigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'transactions', label: 'Transactions', icon: CreditCard },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
  ];

  const accountantSection = [
    { id: 'accountant', label: 'My Accountant', icon: UserCheck },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gray-900">CapAble</h1>
            <p className="text-xs text-gray-500">AI-Powered Accounting</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-1">
        {mainNavigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              className={`w-full justify-start gap-3 h-10 px-3 ${
                isActive 
                  ? 'bg-blue-50 text-blue-700 hover:bg-blue-50' 
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
              onClick={() => onPageChange(item.id)}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Button>
          );
        })}

        <div className="py-4">
          <Separator className="bg-gray-200" />
        </div>

        <div className="space-y-1">
          <p className="px-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Support</p>
          {accountantSection.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <Button
                key={item.id}
                variant="ghost"
                className={`w-full justify-start gap-3 h-10 px-3 ${
                  isActive 
                    ? 'bg-blue-50 text-blue-700 hover:bg-blue-50' 
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
                onClick={() => onPageChange(item.id)}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Button>
            );
          })}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-200">
        <div className="bg-blue-50 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">AI Insights</span>
          </div>
          <p className="text-xs text-blue-700 mb-2">
            Your profit margin improved by 5% this month!
          </p>
          <Button size="sm" variant="outline" className="w-full text-xs border-blue-200 text-blue-700 hover:bg-blue-100">
            View Details
          </Button>
        </div>
      </div>
    </div>
  );
}