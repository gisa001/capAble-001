import React, { useEffect, useState } from 'react'
import { STORAGE_KEYS, load, save } from '../services/storage'

type Account = { id: string, name: string, type?: string }

function uid(){ return Math.random().toString(36).slice(2,9) }

export default function Accounts(){
  const [accounts, setAccounts] = useState<Account[]>(() => load(STORAGE_KEYS.ACCOUNTS, []))
  const [name, setName] = useState('')
  useEffect(() => save(STORAGE_KEYS.ACCOUNTS, accounts), [accounts])

  function add(){
    if(!name.trim()) return alert('Enter account name')
    setAccounts([{id:uid(), name:name.trim()}, ...accounts])
    setName('')
  }
  function remove(id:string){
    if(!confirm('Delete account?')) return
    setAccounts(accounts.filter(a=>a.id!==id))
  }

  return (
    <div>
      <h3>Accounts</h3>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Cash, Sales, Receivables" />
        <button onClick={add}>Add</button>
      </div>
      <ul>
        {accounts.map(a => (
          <li key={a.id} style={{padding:8, borderTop:'1px solid #eee', display:'flex', justifyContent:'space-between'}}>
            <div><strong>{a.name}</strong> <small style={{color:'#666'}}>{a.type || ''}</small></div>
            <div><button onClick={()=>remove(a.id)}>Delete</button></div>
          </li>
        ))}
        {accounts.length===0 && <li><em>No accounts yet</em></li>}
      </ul>
    </div>
  )
}
