import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { 
  MessageCircle, 
  Calendar, 
  FileText, 
  Video, 
  Clock,
  CheckCircle,
  AlertCircle
} from "lucide-react";

export function AccountantSupport() {
  const accountant = {
    name: "Michael Chen, CPA",
    email: "michael@financialpro.com",
    phone: "(555) 123-4567",
    status: "Available",
    nextMeeting: "June 20, 2024 at 2:00 PM",
    specialties: ["Small Business", "Tax Planning", "QuickBooks"]
  };

  const recentMessages = [
    {
      id: 1,
      from: "Michael Chen",
      message: "I've reviewed your Q2 reports. Everything looks great! Your profit margins have improved significantly.",
      timestamp: "2 hours ago",
      unread: true
    },
    {
      id: 2,
      from: "You",
      message: "Should I set aside money for quarterly taxes?",
      timestamp: "1 day ago",
      unread: false
    },
    {
      id: 3,
      from: "Michael Chen",
      message: "Yes, I recommend setting aside 25% of your profit for tax payments. I'll help you calculate the exact amount.",
      timestamp: "1 day ago",
      unread: false
    }
  ];

  const tasks = [
    {
      id: 1,
      title: "Review Q2 Financial Statements",
      status: "completed",
      dueDate: "June 15, 2024"
    },
    {
      id: 2,
      title: "Prepare Quarterly Tax Estimates",
      status: "in-progress",
      dueDate: "June 25, 2024"
    },
    {
      id: 3,
      title: "Business Expense Category Review",
      status: "pending",
      dueDate: "July 1, 2024"
    }
  ];

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">My Accountant</h1>
          <p className="text-gray-600 mt-1">Connect with your dedicated accounting professional</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Accountant Profile */}
          <div className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Your Accountant</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="/placeholder-accountant.jpg" />
                    <AvatarFallback className="bg-blue-100 text-blue-600">MC</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium text-gray-900">{accountant.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">{accountant.status}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-gray-600">📧 {accountant.email}</p>
                  <p className="text-sm text-gray-600">📞 {accountant.phone}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-900 mb-2">Specialties</p>
                  <div className="flex flex-wrap gap-1">
                    {accountant.specialties.map((specialty, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="pt-4 space-y-2">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 gap-2">
                    <MessageCircle className="h-4 w-4" />
                    Send Message
                  </Button>
                  <Button variant="outline" className="w-full gap-2">
                    <Video className="h-4 w-4" />
                    Schedule Video Call
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Next Meeting */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Next Meeting
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-blue-50 rounded-lg p-4">
                  <p className="font-medium text-blue-900">{accountant.nextMeeting}</p>
                  <p className="text-sm text-blue-700 mt-1">Monthly Financial Review</p>
                  <Button size="sm" variant="outline" className="mt-3 border-blue-200 text-blue-700 hover:bg-blue-100">
                    Join Meeting
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Messages and Tasks */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Messages */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-900">Recent Messages</CardTitle>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentMessages.map((message) => (
                  <div key={message.id} className={`p-4 rounded-lg border ${
                    message.unread ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">{message.from}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">{message.timestamp}</span>
                        {message.unread && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-gray-700">{message.message}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Tasks and Deliverables */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Tasks & Deliverables</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {tasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        task.status === 'completed' 
                          ? 'bg-green-100' 
                          : task.status === 'in-progress' 
                          ? 'bg-yellow-100' 
                          : 'bg-gray-100'
                      }`}>
                        {task.status === 'completed' ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : task.status === 'in-progress' ? (
                          <Clock className="h-4 w-4 text-yellow-600" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-gray-600" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{task.title}</p>
                        <p className="text-sm text-gray-600">Due: {task.dueDate}</p>
                      </div>
                    </div>
                    <Badge 
                      variant={task.status === 'completed' ? 'default' : 'secondary'}
                      className={
                        task.status === 'completed' 
                          ? 'bg-green-100 text-green-800' 
                          : task.status === 'in-progress'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }
                    >
                      {task.status === 'completed' ? 'Completed' : 
                       task.status === 'in-progress' ? 'In Progress' : 'Pending'}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start gap-3 h-12">
                    <FileText className="h-5 w-5" />
                    Request Financial Report
                  </Button>
                  <Button variant="outline" className="justify-start gap-3 h-12">
                    <Calendar className="h-5 w-5" />
                    Schedule Tax Planning
                  </Button>
                  <Button variant="outline" className="justify-start gap-3 h-12">
                    <MessageCircle className="h-5 w-5" />
                    Ask a Question
                  </Button>
                  <Button variant="outline" className="justify-start gap-3 h-12">
                    <Video className="h-5 w-5" />
                    Book Consultation
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}