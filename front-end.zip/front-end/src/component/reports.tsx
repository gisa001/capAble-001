import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { Download, FileText, Calculator, TrendingUp, Calendar } from "lucide-react";

export function Reports() {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedYear, setSelectedYear] = useState('2024');

  // Sample data for different reports
  const incomeStatementData = [
    { category: 'Revenue', accounts: [
      { name: 'Sales Revenue', amount: 328000 },
      { name: 'Service Revenue', amount: 45000 },
      { name: 'Other Income', amount: 5000 }
    ]},
    { category: 'Cost of Goods Sold', accounts: [
      { name: 'Materials', amount: 120000 },
      { name: 'Direct Labor', amount: 60000 }
    ]},
    { category: 'Operating Expenses', accounts: [
      { name: 'Rent Expense', amount: 60000 },
      { name: 'Salaries', amount: 150000 },
      { name: 'Marketing', amount: 24000 },
      { name: 'Utilities', amount: 18000 },
      { name: 'Software', amount: 12000 }
    ]}
  ];

  const balanceSheetData = [
    { category: 'Assets', subcategory: 'Current Assets', accounts: [
      { name: 'Cash in Bank', amount: 45000 },
      { name: 'Accounts Receivable', amount: 32000 },
      { name: 'Inventory', amount: 28000 }
    ]},
    { category: 'Assets', subcategory: 'Fixed Assets', accounts: [
      { name: 'Equipment', amount: 85000 },
      { name: 'Accumulated Depreciation', amount: -15000 }
    ]},
    { category: 'Liabilities', subcategory: 'Current Liabilities', accounts: [
      { name: 'Accounts Payable', amount: 15000 },
      { name: 'Accrued Expenses', amount: 8000 }
    ]},
    { category: 'Liabilities', subcategory: 'Long-term Liabilities', accounts: [
      { name: 'Loan Payable', amount: 50000 }
    ]},
    { category: 'Equity', subcategory: 'Owner\'s Equity', accounts: [
      { name: 'Capital', amount: 100000 },
      { name: 'Retained Earnings', amount: 25000 },
      { name: 'Current Year Earnings', amount: 17000 }
    ]}
  ];

  const cashFlowData = [
    { month: 'Jan', inflow: 65000, outflow: 52000, net: 13000 },
    { month: 'Feb', inflow: 78000, outflow: 58000, net: 20000 },
    { month: 'Mar', inflow: 62000, outflow: 55000, net: 7000 },
    { month: 'Apr', inflow: 85000, outflow: 62000, net: 23000 },
    { month: 'May', inflow: 72000, outflow: 59000, net: 13000 },
    { month: 'Jun', inflow: 88000, outflow: 65000, net: 23000 }
  ];

  const profitTrendData = [
    { month: 'Jan', grossProfit: 25000, netProfit: 13000 },
    { month: 'Feb', grossProfit: 32000, netProfit: 20000 },
    { month: 'Mar', grossProfit: 28000, netProfit: 7000 },
    { month: 'Apr', grossProfit: 38000, netProfit: 23000 },
    { month: 'May', grossProfit: 35000, netProfit: 13000 },
    { month: 'Jun', grossProfit: 42000, netProfit: 23000 }
  ];

  const expenseBreakdown = [
    { name: 'Salaries', value: 150000, color: '#8884d8' },
    { name: 'Rent', value: 60000, color: '#82ca9d' },
    { name: 'Marketing', value: 24000, color: '#ffc658' },
    { name: 'Utilities', value: 18000, color: '#ff7300' },
    { name: 'Other', value: 12000, color: '#8dd1e1' }
  ];

  const calculateTotal = (accounts: any[]) => {
    return accounts.reduce((sum, account) => sum + account.amount, 0);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Financial Reports</h1>
          <p className="text-muted-foreground">Generate and analyze your financial statements</p>
        </div>
        
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Monthly</SelectItem>
              <SelectItem value="quarter">Quarterly</SelectItem>
              <SelectItem value="year">Yearly</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <Tabs defaultValue="income-statement" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="income-statement" className="gap-2">
            <Calculator className="h-4 w-4" />
            Income Statement
          </TabsTrigger>
          <TabsTrigger value="balance-sheet" className="gap-2">
            <FileText className="h-4 w-4" />
            Balance Sheet
          </TabsTrigger>
          <TabsTrigger value="cash-flow" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Cash Flow
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <Calendar className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="income-statement" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Income Statement - June 2024</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {incomeStatementData.map((section, index) => (
                  <div key={index}>
                    <h3 className="font-medium text-lg mb-3">{section.category}</h3>
                    <div className="space-y-2">
                      {section.accounts.map((account, accountIndex) => (
                        <div key={accountIndex} className="flex justify-between items-center py-1">
                          <span className="text-muted-foreground">{account.name}</span>
                          <span>{formatCurrency(account.amount)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between items-center py-2 border-t font-medium">
                        <span>Total {section.category}</span>
                        <span>{formatCurrency(calculateTotal(section.accounts))}</span>
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="border-t-2 pt-4 mt-6">
                  <div className="flex justify-between items-center text-lg font-medium">
                    <span>Net Income</span>
                    <span className="text-green-600">{formatCurrency(139000)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="balance-sheet" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Assets</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {balanceSheetData.filter(section => section.category === 'Assets').map((section, index) => (
                    <div key={index}>
                      <h4 className="font-medium mb-2">{section.subcategory}</h4>
                      <div className="space-y-1 ml-4">
                        {section.accounts.map((account, accountIndex) => (
                          <div key={accountIndex} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{account.name}</span>
                            <span>{formatCurrency(Math.abs(account.amount))}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  <div className="border-t pt-2 mt-4">
                    <div className="flex justify-between font-medium">
                      <span>Total Assets</span>
                      <span>{formatCurrency(175000)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Liabilities & Equity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {balanceSheetData.filter(section => section.category !== 'Assets').map((section, index) => (
                    <div key={index}>
                      <h4 className="font-medium mb-2">{section.subcategory}</h4>
                      <div className="space-y-1 ml-4">
                        {section.accounts.map((account, accountIndex) => (
                          <div key={accountIndex} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{account.name}</span>
                            <span>{formatCurrency(account.amount)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  <div className="border-t pt-2 mt-4">
                    <div className="flex justify-between font-medium">
                      <span>Total Liabilities & Equity</span>
                      <span>{formatCurrency(175000)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cash-flow" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Cash Flow Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Bar dataKey="inflow" fill="#10b981" name="Cash Inflow" />
                    <Bar dataKey="outflow" fill="#ef4444" name="Cash Outflow" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Net Cash Flow</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Line type="monotone" dataKey="net" stroke="#8884d8" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Cash Flow Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Month</TableHead>
                    <TableHead className="text-right">Cash Inflow</TableHead>
                    <TableHead className="text-right">Cash Outflow</TableHead>
                    <TableHead className="text-right">Net Cash Flow</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cashFlowData.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell>{row.month}</TableCell>
                      <TableCell className="text-right text-green-600">{formatCurrency(row.inflow)}</TableCell>
                      <TableCell className="text-right text-red-600">{formatCurrency(row.outflow)}</TableCell>
                      <TableCell className="text-right">
                        <span className={row.net > 0 ? 'text-green-600' : 'text-red-600'}>
                          {formatCurrency(row.net)}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Profit Trend Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={profitTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Line type="monotone" dataKey="grossProfit" stroke="#10b981" name="Gross Profit" />
                    <Line type="monotone" dataKey="netProfit" stroke="#3b82f6" name="Net Profit" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Expense Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={expenseBreakdown}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {expenseBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Profit Margin</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">37.2%</div>
                <div className="text-xs text-muted-foreground">+2.1% from last month</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">ROI</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">24.8%</div>
                <div className="text-xs text-muted-foreground">+5.3% from last month</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Quick Ratio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl">3.2</div>
                <div className="text-xs text-muted-foreground">Healthy liquidity</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}