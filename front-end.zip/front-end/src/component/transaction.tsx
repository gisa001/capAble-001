import React, { useEffect, useState } from 'react'
import { STORAGE_KEYS, load, save } from '../services/storage'

type Transaction = {
  id: string
  date: string
  account: string
  description: string
  amount: number
  type: 'debit' | 'credit'
}

function uid() {
  return Math.random().toString(36).slice(2,9)
}

export default function Transactions() {
  const [transactions, setTransactions] = useState<Transaction[]>(() => load(STORAGE_KEYS.TRANSACTIONS, []))
  const [form, setForm] = useState({date: '', account: '', description: '', amount: '', type: 'debit'})

  useEffect(() => {
    save(STORAGE_KEYS.TRANSACTIONS, transactions)
  }, [transactions])

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    setForm({...form, [e.target.name]: e.target.value})
  }

  function addTransaction(e?: React.FormEvent) {
    if (e) e.preventDefault()
    const amt = parseFloat(form.amount || '0')
    if (!form.date || !form.account || !amt) return alert('Please fill date, account and amount')
    const t: Transaction = { id: uid(), date: form.date, account: form.account, description: form.description, amount: amt, type: form.type as any }
    setTransactions([t, ...transactions])
    setForm({date:'', account:'', description:'', amount:'', type:'debit'})
  }

  function removeTransaction(id: string) {
    if (!confirm('Delete transaction?')) return
    setTransactions(transactions.filter(t => t.id !== id))
  }

  function exportCSV() {
    const header = ['id','date','account','description','amount','type']
    const rows = transactions.map(t => [t.id,t.date,t.account,t.description,String(t.amount),t.type])
    const csv = [header, ...rows].map(r => r.map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n')
    const blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'capable_transactions.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div>
      <h3>Transactions</h3>
      <form onSubmit={addTransaction} style={{display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:8, alignItems:'end'}}>
        <div>
          <label>Date</label><br />
          <input name="date" type="date" value={form.date} onChange={handleChange} />
        </div>
        <div>
          <label>Account</label><br />
          <input name="account" value={form.account} onChange={handleChange} placeholder="Cash, Sales, etc." />
        </div>
        <div style={{gridColumn:'span 2'}}>
          <label>Description</label><br />
          <input name="description" value={form.description} onChange={handleChange} placeholder="What was this for?" style={{width:'100%'}} />
        </div>
        <div>
          <label>Amount</label><br />
          <input name="amount" type="number" step="0.01" value={form.amount} onChange={handleChange} />
        </div>
        <div style={{gridColumn:'1/-1', marginTop:6, display:'flex', gap:8}}>
          <select name="type" value={form.type} onChange={handleChange}>
            <option value="debit">Debit</option>
            <option value="credit">Credit</option>
          </select>
          <button type="submit">Add</button>
          <button type="button" onClick={exportCSV}>Export CSV</button>
        </div>
      </form>

      <hr />

      <table style={{width:'100%', borderCollapse:'collapse'}}>
        <thead style={{textAlign:'left'}}>
          <tr><th>Date</th><th>Account</th><th>Description</th><th>Amount</th><th>Type</th><th></th></tr>
        </thead>
        <tbody>
          {transactions.map(t => (
            <tr key={t.id} style={{borderTop:'1px solid #eee'}}>
              <td>{t.date}</td>
              <td>{t.account}</td>
              <td>{t.description}</td>
              <td>{t.amount.toFixed(2)}</td>
              <td>{t.type}</td>
              <td><button onClick={() => removeTransaction(t.id)}>Delete</button></td>
            </tr>
          ))}
          {transactions.length === 0 && <tr><td colSpan={6}><em>No transactions yet.</em></td></tr>}
        </tbody>
      </table>
    </div>
  )
}
