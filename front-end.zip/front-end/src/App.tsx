import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Dashboard from './components/Dashboard'
import Transactions from './components/Transactions'
import Accounts from './components/Accounts'
import Reports from './components/Reports'
import Settings from './components/Settings'
import './index.css'

export default function App() {
  return (
    <div className="app-root" style={{fontFamily: 'Inter, Arial, sans-serif'}}>
      <header style={{padding:20, borderBottom:'1px solid #eee', display:'flex', justifyContent:'space-between'}}>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <h2 style={{margin:0}}>CapAble</h2>
          <nav style={{display:'flex', gap:8}}>
            <Link to="/">Dashboard</Link>
            <Link to="/transactions">Transactions</Link>
            <Link to="/accounts">Accounts</Link>
            <Link to="/reports">Reports</Link>
            <Link to="/settings">Settings</Link>
          </nav>
        </div>
        <div>
          <small>You're using a local demo version — data is saved in your browser.</small>
        </div>
      </header>

      <main style={{padding:20}}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/transactions" element={<Transactions />} />
          <Route path="/accounts" element={<Accounts />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  )
}
