export const STORAGE_KEYS = {
  ACCOUNTS: 'capable_accounts_v1',
  TRANSACTIONS: 'capable_transactions_v1',
}

export function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw)
  } catch (e) {
    console.error('load error', e)
    return fallback
  }
}

export function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (e) {
    console.error('save error', e)
  }
}
