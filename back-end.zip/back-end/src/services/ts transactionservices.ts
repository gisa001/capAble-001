import prisma from '../prisma/client';

export async function getUserTransactions(userId: string) {
  const businesses = await prisma.business.findMany({
    where: {
      OR: [
        { ownerId: userId },
        { accessGrants: { some: { userId } } }
      ]
    },
    select: { id: true }
  });
  const businessIds = businesses.map(b => b.id);
  return prisma.transaction.findMany({
    where: { businessId: { in: businessIds } }
  });
}

export async function createTransaction(data: {
  amount: number;
  description: string;
  type: string;
  category?: string;
  date: Date;
  businessId: string;
}) {
  return prisma.transaction.create({ data });
}