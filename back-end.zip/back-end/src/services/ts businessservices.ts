import prisma from '../prisma/client';

export async function getUserBusinesses(userId: string) {
  return prisma.business.findMany({ where: { ownerId: userId } });
}

export async function createBusiness(userId: string, name: string) {
  return prisma.business.create({
    data: { name, ownerId: userId },
  });
}