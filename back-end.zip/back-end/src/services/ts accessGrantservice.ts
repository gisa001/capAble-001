import prisma from '../prisma/client';

export async function createAccessGrant(data: {
  userId: string;
  businessId: string;
  role: string;
  canEdit?: boolean;
}) {
  return prisma.accessGrant.create({ data });
}