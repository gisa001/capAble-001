import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import errorHandler from './middlewares/errorHandler';
import authRoutes from './routes/authRoutes';
import businessRoutes from './routes/businessRoutes';
import transactionRoutes from './routes/transactionRoutes';
import accessGrantRoutes from './routes/accessGrantRoutes';

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api', authRoutes);
app.use('/api/businesses', businessRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/access-grants', accessGrantRoutes);

app.use(errorHandler);

export default app;