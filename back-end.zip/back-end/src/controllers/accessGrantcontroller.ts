import { Request, Response } from 'express';
import prisma from '../prisma/client';

export async function createAccessGrant(req: any, res: Response) {
  const { userId, businessId, role, canEdit } = req.body;
  // Only business owner can invite
  const business = await prisma.business.findUnique({ where: { id: businessId } });
  if (!business || business.ownerId !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Only owner can invite' });
  }
  const grant = await prisma.accessGrant.create({
    data: { userId, businessId, role, canEdit }
  });
  res.status(201).json({ success: true, grant });
}