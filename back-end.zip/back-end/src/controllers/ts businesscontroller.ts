import { Request, Response } from 'express';
import prisma from '../prisma/client';

export async function getBusinesses(req: any, res: Response) {
  const userId = req.user.id;
  const businesses = await prisma.business.findMany({
    where: { ownerId: userId },
  });
  res.json({ success: true, businesses });
}

export async function createBusiness(req: any, res: Response) {
  const { name } = req.body;
  const userId = req.user.id;
  const business = await prisma.business.create({
    data: { name, ownerId: userId },
  });
  res.status(201).json({ success: true, business });
}