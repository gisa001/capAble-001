import { Request, Response } from 'express';
import prisma from '../prisma/client';
S
export async function getTransactions(req: any, res: Response) {
  const userId = req.user.id;
  // Get businesses user owns or has access to
  const businesses = await prisma.business.findMany({
    where: {
      OR: [
        { ownerId: userId },
        { accessGrants: { some: { userId } } }
      ]
    },
    select: { id: true }
  });
  const businessIds = businesses.map(b => b.id);
  const transactions = await prisma.transaction.findMany({
    where: { businessId: { in: businessIds } }
  });
  res.json({ success: true, transactions });
}

export async function createTransaction(req: any, res: Response) {
  const { amount, description, type, category, date, businessId } = req.body;
  // Validate user access to business
  const userId = req.user.id;
  const business = await prisma.business.findFirst({
    where: {
      id: businessId,
      OR: [
        { ownerId: userId },
        { accessGrants: { some: { userId } } }
      ]
    }
  });
  if (!business) {
    return res.status(403).json({ success: false, message: 'No access to this business' });
  }
  const transaction = await prisma.transaction.create({
    data: { amount, description, type, category, date, businessId }
  });
  res.status(201).json({ success: true, transaction });
}c