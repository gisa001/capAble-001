import { Request, Response, NextFunction } from 'express';
import prisma from '../prisma/client';

export function requireRole(roles: string[]) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Forbidden: insufficient role' });
    }
    next();
  };
}

// For AccessGrant-based permissions
export async function requireAccessGrant(req: any, res: Response, next: NextFunction) {
  const userId = req.user?.id;
  const businessId = req.params.businessId || req.body.businessId;
  if (!userId || !businessId) {
    return res.status(400).json({ success: false, message: 'Missing user or business' });
  }
  const grant = await prisma.accessGrant.findUnique({
    where: { userId_businessId: { userId, businessId } },
  });
  if (!grant) {
    return res.status(403).json({ success: false, message: 'No access grant found' });
  }
  req.accessGrant = grant;
  next();
}