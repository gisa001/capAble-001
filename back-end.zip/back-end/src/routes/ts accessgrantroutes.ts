import { Router } from 'express';
import authMiddleware from '../middlewares/authMiddleware';
import { createAccessGrant } from '../controllers/accessGrantController';
import { body } from 'express-validator';

const router = Router();

router.use(authMiddleware);

router.post('/', [
  body('userId').notEmpty(),
  body('businessId').notEmpty(),
  body('role').isIn(['ACCOUNTANT', 'INVESTOR']),
], createAccessGrant);

export default router;