import { Router } from 'express';
import authMiddleware from '../middlewares/authMiddleware';
import { getBusinesses, createBusiness } from '../controllers/businessController';
import { body } from 'express-validator';

const router = Router();

router.use(authMiddleware);

router.get('/', getBusinesses);
router.post('/', [body('name').notEmpty()], createBusiness);

export default router;