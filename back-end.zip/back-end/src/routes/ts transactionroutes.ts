import { Router } from 'express';
import authMiddleware from '../middlewares/authMiddleware';
import { getTransactions, createTransaction } from '../controllers/transactionController';
import { body } from 'express-validator';

const router = Router();

router.use(authMiddleware);

router.get('/', getTransactions);
router.post('/', [
  body('amount').isNumeric(),
  body('description').notEmpty(),
  body('type').isIn(['INCOME', 'EXPENSE']),
  body('businessId').notEmpty(),
  body('date').isISO8601()
], createTransaction);

export default router;