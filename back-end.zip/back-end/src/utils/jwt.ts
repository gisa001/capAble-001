import jwt from 'jsonwebtoken';
import config from '../config';

export function signJwt(payload: object, expiresIn = '7d') {
  return jwt.sign(payload, config.JWT_SECRET, { expiresIn });
}

export function verifyJwt(token: string) {
  return jwt.verify(token, config.JWT_SECRET);
}